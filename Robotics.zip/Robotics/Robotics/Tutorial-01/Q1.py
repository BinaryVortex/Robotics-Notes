# Initialize dictionary
student_grades = {}

# Getting inputs
for i in range(0,5):
    name = input(f"Enter the name of student {i+1}: ")
    
    grade = float(input(f"Enter the average grade of {name}: "))
    
    # Add the name and grade to the dictionary
    student_grades[name] = grade

# Print the dictionary
for name, grade in student_grades.items():
    hi = f"{name}: {grade}"
    print(type(hi))
