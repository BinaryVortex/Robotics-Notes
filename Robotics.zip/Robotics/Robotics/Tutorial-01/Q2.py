# Initializing variables
total = 0
a = []
b = []

# Check the length of the input
def check_inputs(a,b,total):
    if len(a) != len(b):
        print("\nList length should be equal")
    else:
        # Calculation
        for i in range (0,len(a)):
            value = a[i] * b[i]
            total += value
            print(total)

# Getting inputs for a
num = int(input("How many inputs do you want for list a : "))

for i in range(0,num):
    number = int(input(f"Enter {i} number : "))
    a.append(number)

# Getting inputs for b
num = int(input("\nHow many inputs do you want for list b : "))

for i in range(0,num):
    number = int(input(f"Enter {i} number : "))
    b.append(number)

# Call the function
check_inputs(a,b,total)

