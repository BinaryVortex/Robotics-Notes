a = []

num = int(input("How many inputs do you want for list : "))
for i in range (0,num):
    number = int(input(f"Enter {i} number : "))
    a.append(i)

n1 = int(input("\nEnter a integer input for n1 : "))
n2 = int(input("Enter a integer input for n2 : "))

def my_list(a,n1,n2):
    ans = []
    for i in a:
        if n1 <= i <= n2:
            ans.append(i)
            print(ans)
        else:
            print("There are no values")
