% Define transfer function for the PID controller (example)
Kp = 1; Ki = 1; Kd = 0; % PID parameters
PID = tf([Kd Kp Ki], [1 0]);

% Define other system components based on your diagram
A1 = 2; % Amplification factor for path 1
A2 = 3; % Amplification factor for path 2
K1 = 0.4; % Gain for path 1
K2 = 0.3; % Gain for path 2

% Define transfer functions for paths
path1 = A1 * tf(1, [1 1]) * sqrt(1); % Example path 1 components
path2 = A2 * tf(1, [1 1]) * sqrt(1); % Example path 2 components

% Combine into overall system
feedback1 = feedback(path1 * K1, 1); % Path 1 feedback loop
feedback2 = feedback(path2 * K2, 1); % Path 2 feedback loop

% Combine all paths with PID
sys = series(PID, parallel(feedback1, feedback2));

% Time vector
t = 0:0.005:3;

% Step response
[y, t] = step(sys, t);

% Plot step response
figure;
plot(t, y, 'LineWidth', 3);
grid on;
xlabel('time (s)');
ylabel('System Output');
title('Step Response of the System');

% Generate Bode plot
figure;
bode(sys);
grid on;
title('Bode Diagram of the System');