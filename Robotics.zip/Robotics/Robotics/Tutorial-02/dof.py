def dof(m, n, j, total_freedom):
    dof = m * (n - 1 - j) + total_freedom
    return dof

# Input the degrees of freedom of a rigid body
m = int(input("Enter the degrees of freedom of a rigid body ( 3 for planar and 6 for spacial ): "))
# Input the number of links
n = int(input("Number of links ( including the ground ): "))
# Input the number of joints
j = int(input("Number of joints: "))

# Initialize the total freedom of joints
total_freedom = 0

# Collect the freedom of each joint and accumulate the total
for i in range(1, j + 1):
    freedom_of_each_joint = int(input(f"Degrees of freedom for joint {i}: "))
    total_freedom += freedom_of_each_joint

# Calculate and print the degrees of freedom
print("Degrees of Freedom:", dof(m, n, j, total_freedom))
