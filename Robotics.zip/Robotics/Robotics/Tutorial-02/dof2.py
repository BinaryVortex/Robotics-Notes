def calculate_robot_dof():
    # Prompt the user for joint counts
    revolute_joints = int(input("Enter the number of revolute joints: "))
    prismatic_joints = int(input("Enter the number of prismatic joints: "))
    helical_joints = int(input("Enter the number of helical joints: "))
    cylindrical_joints = int(input("Enter the number of cylindrical joints: "))
    universal_joints = int(input("Enter the number of universal joints: "))
    spherical_joints = int(input("Enter the number of spherical joints: "))

    # Calculate the total number of joints
    J = (revolute_joints + prismatic_joints + helical_joints +
         cylindrical_joints + universal_joints + spherical_joints)

    # Prompt the user for the number of links
    N = int(input("Enter the number of links (including the ground): "))

    # Ask if the body is planar or spatial
    body_type = input("Is the body planar or spatial? ").strip().lower()

    # Determine the degrees of freedom of a rigid body
    if body_type == "planar":
        m = 3
    elif body_type == "spatial":
        m = 6
    else:
        raise ValueError("Invalid body type. Please enter 'planar' or 'spatial'.")

    # Collect the degrees of freedom for each joint
    freedom_list = []
    for i in range(1, J + 1):
        fi = int(input(f"Enter the degrees of freedom for joint {i}: "))
        freedom_list.append(fi)

    # Calculate the total degrees of freedom using Grübler's formula
    dof = m * (N - 1 - J) + sum(freedom_list)

    # Construct the formatted output string
    freedom_str = "\n".join([f"f_{i} = {freedom_list[i-1]}" for i in range(1, J + 1)])
    formula_str = " + ".join([f"{freedom_list[i]}" for i in range(J)])
    result_str = (
        f"m = {m} ({body_type})\n"
        f"J = {J}\n"
        f"N = {N} (including the ground)\n"
        f"{freedom_str}\n"
        f"dof = {m} * ({N} - 1 - {J}) + {formula_str} = {dof}"
    )

    return result_str

# Example usage
result = calculate_robot_dof()
print(result)